# 打印数字
num = input("请输入一个不多于5位正整数：")
i=0
for item in num:
    i+=1
    print(item)
print("是一个%d位数"%i)