# 判断随机数能否被5和6同时整除
num = int(input("请输入一个整数："))
if num%5 == 0 and num%6 ==0:
    print("%d能被5和6整除"%num)
elif num%5 == 0 and num%6 == 1:
    print("%d只能被5整除" % num)
elif num%5 == 1 and num%6 == 0:
    print("%d只能被6整除" % num)
else:
    print("%d不能被5和6整除" % num)