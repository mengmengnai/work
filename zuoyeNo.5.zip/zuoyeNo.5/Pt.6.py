# 猴子吃桃
surplus = 1
for day in range(1,10):
    surplus = (surplus+1)*2
print("第一天共摘%d个桃子"%surplus)