# 将一个数反转后的数
num = input("请输入一个四位整数：")
Num = str(num)
Num = num[::-1]
num = int(Num)
print(Num)