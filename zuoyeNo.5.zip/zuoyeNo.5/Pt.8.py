# 1到100之间所有能被3整除的整数的和
sum = 0
for num in range(0,100):
    if num%3 == 0:
        sum = sum + num
print(sum)


# *****************************************
Num = 0
Sum = 0
while Num < 100:
    if Num % 3 == 0:
        Sum = Sum + Num
    Num += 1
print(Sum)