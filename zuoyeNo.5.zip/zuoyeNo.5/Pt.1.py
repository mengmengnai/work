# 企业发放奖金
num = int(input("请输入当月利润(万元)："))
sum = 0

if num <= 10:
    sum = num*0.1
elif num <= 20:
    sum = 1+(num-10)*0.075
elif num <= 40:
    sum = 1.75+(num-20)*0.05
elif num <= 60:
    sum = 2.75+(num-40)*0.03
elif num <= 100:
    sum = 3.35+(num-60)*0.015
else:
    sum = 3.95+(num-100)*0.01
print("应发奖金%0.2f万元" % sum)